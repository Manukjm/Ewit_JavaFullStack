package com.tns.collections.set;

import java.util.LinkedHashSet;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		LinkedHashSet<String> lhs=new LinkedHashSet<>();
		lhs.add(null);
		lhs.add("India");
		lhs.add("Japan");
		lhs.add("America");

		System.out.println(lhs);
		
	}

}
