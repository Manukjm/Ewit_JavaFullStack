package com.tns.collections.set;

import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		TreeSet<String> ts=new TreeSet<>();
		ts.add("Thailand");
		ts.add("America");
		ts.add("Nethrland");
		ts.add("Japan");
		
		System.out.println(ts);

	}

}
