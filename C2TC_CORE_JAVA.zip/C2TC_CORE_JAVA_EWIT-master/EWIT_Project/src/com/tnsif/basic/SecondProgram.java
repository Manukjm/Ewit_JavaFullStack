package com.tnsif.basic;

public class SecondProgram {

	public static void main(String[] args) {
		System.out.println("Second Program");
	}

}
