package com.tnsif.basic;

public class SAmpleOne {

}
