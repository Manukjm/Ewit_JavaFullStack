package com.tnsif.basic;

import java.awt.TextField;

public class FirstProgram {

	public static void main(String[] args) {
	System.out.println("Hello World");
	TextField tf=new TextField();
	Sample s=new Sample();
	s.display();
	}
}
