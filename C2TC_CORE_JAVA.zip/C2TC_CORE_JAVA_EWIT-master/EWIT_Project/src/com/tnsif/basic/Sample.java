package com.tnsif.basic;

public class Sample {
	
	int a=10;
	int x=10;
	
	void display() {
		System.out.println("Value of a and x is "+a+" "+x);
	}

}
