package com.tnsif.finaldemo;

public class FinalMethodDemo extends FinalMethodClass {
	
	@Override
	void display() {
		
	}
	//Final methods can't be overrided
	/*
	 * @Override void show() { }
	 */
	
}
