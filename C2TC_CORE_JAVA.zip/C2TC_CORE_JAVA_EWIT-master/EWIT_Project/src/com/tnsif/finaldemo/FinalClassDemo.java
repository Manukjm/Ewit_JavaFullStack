package com.tnsif.finaldemo;

class Demo{
	
}
final class FinalClass{
	
}

//Final Class can't be inherited
/*public class FinalClassDemo extends FinalClass{
public static void main(String args[]) {
	
}
}*/
