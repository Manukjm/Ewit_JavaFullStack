package com.tnsif.generics;

public class GenericClass<T> {
	T data;

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

}
