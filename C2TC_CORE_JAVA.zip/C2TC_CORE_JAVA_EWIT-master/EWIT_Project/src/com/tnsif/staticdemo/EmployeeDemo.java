package com.tnsif.staticdemo;

public class EmployeeDemo {

	public static void main(String[] args) {
		Employee e1=new Employee("Robert",101);
		Employee e2=new Employee("Alex",102);
		Employee e3=new Employee("Tom",103);
		Employee e4=new Employee("Alexa",104);
		
		
System.out.println(e1);
System.out.println(e2);
System.out.println(e3);
System.out.println(e4);

	}

}
