package com.tnsif.abstraction;

public abstract class AbstractionDemo {

	AbstractionDemo(){
		
	}
	
void m1() {
	
}

abstract void m2();
}
