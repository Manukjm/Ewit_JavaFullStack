package com.tnsif.interfaces;


public interface DemoMarkerInterface {

}
Cloneable