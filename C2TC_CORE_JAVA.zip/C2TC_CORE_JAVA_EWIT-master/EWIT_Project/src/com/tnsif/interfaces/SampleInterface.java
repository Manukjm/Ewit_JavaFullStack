package com.tnsif.interfaces;

public interface SampleInterface {
int a=10;

 void display();

 void show();
 default void m1(){
	
}
}
