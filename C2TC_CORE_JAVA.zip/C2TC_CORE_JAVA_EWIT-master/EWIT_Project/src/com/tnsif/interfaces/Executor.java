package com.tnsif.interfaces;

public class Executor {

	public static void main(String[] args) {
		SampleInterface obj;
		Derived d=new Derived();
		d.display();

	}

}
