package com.tnsif.arrays;

import java.util.Arrays;
import java.util.Scanner;

import com.tnsif.staticdemo.Employee;

public class ArraysDemo {

	public static void main(String[] args) {
		/*
		 * String days[]=new String[7]; //days[0]="Monday"; Scanner sc=new
		 * Scanner(System.in); for(int i=0;i<days.length;i++) {
		 * System.out.println("Please enter the "+i+"th day of the week");
		 * days[i]=sc.nextLine(); } System.out.println("Days of the week are"); for(int
		 * i=0;i<days.length;i++) { System.out.println(days[i]); }
		 */
		int arr1[]= {100,20,300,40,50};
		
		//Arrays.sort(arr1);
		for(int i=0;i<arr1.length;i++)
		{
		System.out.println(arr1[i]);
		}
   
	}
}
Thread