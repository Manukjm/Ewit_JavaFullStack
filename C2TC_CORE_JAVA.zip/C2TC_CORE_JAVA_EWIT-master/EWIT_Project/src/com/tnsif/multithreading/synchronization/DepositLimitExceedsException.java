package com.tnsif.multithreading.synchronization;

public class DepositLimitExceedsException extends Exception {

}
